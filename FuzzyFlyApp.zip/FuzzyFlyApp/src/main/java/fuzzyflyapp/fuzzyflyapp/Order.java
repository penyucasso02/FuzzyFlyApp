/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuzzyflyapp.fuzzyflyapp;

/**
 *
 * @author aliya
 */
abstract public class Order implements OrderShipment{
    protected String orderID;
    protected Customer customer;
    protected Payment payment;
    protected DeliveryPerson deliveryPerson;

    public Order(String orderID, Customer customer, Payment payment, DeliveryPerson deliveryPerson) {
        this.orderID = orderID;
        this.customer = customer;
        this.payment = payment;
        this.deliveryPerson = deliveryPerson;
    }

    public abstract double calculateTotalPrice(int quantity);  

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public DeliveryPerson getDeliveryPerson() {
        return deliveryPerson;
    }

    public void setDeliveryPerson(DeliveryPerson deliveryPerson) {
        this.deliveryPerson = deliveryPerson;
    }

    @Override
    public void shipOut() {
        System.out.println("Order has been shipped out!");
    }

    @Override
    public void shipmentNotice() {
        System.out.println("Please make sure to make payment in less than a week from today.");
    }

    @Override
    public void showCompany() {
        System.out.println("Delivery Company: "+COMPANY);
        System.out.println("Thank you for using our service!");
    }
    
    
}
