/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package fuzzyflyapp.fuzzyflyapp;

import java.util.Scanner;

/**
 *
 * @author aliya
 * 
 * NAME: ALIYA MAISARAH BINTI KASIM
 * MATRIC ID: CD22028
 * SECTION: 02B
 * LECTURER NAME: DR. AMEERAH MUHSINAH BINTI JAMIL
 * SUB-SYSTEM: SHIPPING AND DELIVERY OF FURNITURE
 * 
 */
public class Project {

    public static void start(Scanner scanner) {
        
        Scanner input = new Scanner(System.in);
        int flag=0;
        
        while(flag==0){
        //declare furniture
        System.out.println("");
        Furniture[] arrFurniture = new Furniture[5];
        arrFurniture[0] = new Furniture("A2", "IKEA", "Shelf", "L80 x W30 x H168 (cm）", "Easy to install, high quality materials", 87.9);
        arrFurniture[1] = new Furniture("G5", "Fuyoo", "Sofa", "W3200 x D2000 x H820 (cm)", "High Quality Microfabric", 3999.0);
        arrFurniture[2] = new Furniture("H9", "Sen", "Buffet Table", "W160 x D45 x H85 (cm)", "Compact, with two storage. Can be used as a sideboard", 2593.0);
        arrFurniture[3] = new Furniture("P8", "Jorlaina", "Dresser Table", "L100 x W40 x H120 (cm)", "Strong material", 2299.66);
        arrFurniture[4] = new Furniture("X4", "Elleni", "Nightstand", "L45 x D40 x H95 (cm)", "Item comes with 1-year structural warranty and does not include damages from wear and tear.", 1030.0);
        
        //order
        System.out.println("-- FURNITURE ORDER --");
        System.out.println("");
       
        System.out.println("CUSTOMER DETAIL");
        System.out.println("Please enter your name: ");
        String customerName = input.next(); //no space
        System.out.println("Please enter your email: ");
        String customerEmail = input.next();
        System.out.println("Please enter your address: ");
        String customerAddress = input.next(); //no space
        System.out.println("Please enter your phone number: ");
        String customerPhoneNumber = input.next();
        System.out.println("Please enter today's date: ");
        String date = input.next();
        Customer customer = new Customer(customerName, customerEmail, customerAddress, customerPhoneNumber);
        Order order = new FurnitureOrder("F1231", customer, null, null);
        
        //pick furniture
        System.out.println("FURNITURE DETAIL");
        for(int i=0;i<arrFurniture.length;i++){ //
            System.out.println("");
            System.out.println("Furniture "+(i+1));
            System.out.println("Item ID: "+arrFurniture[i].getId());
            System.out.println("Brand: "+arrFurniture[i].getBrand()); 
            System.out.println("Type: "+arrFurniture[i].getType()); 
            System.out.println("Dimension: "+arrFurniture[i].getDimensions()); 
            System.out.println("Description: "+arrFurniture[i].getDescription()); 
            System.out.println("Price: "+arrFurniture[i].getPrice()); 
        }
        System.out.println("How many furniture do you want to buy?");
        int quantity = input.nextInt();
        
        Furniture[] chosenItem = new Furniture[quantity];
        for(int j=0;j<quantity;j++) { 
            System.out.println("Please enter the item ID: ");
            String id = input.next();
            if(id.equalsIgnoreCase("A2")){
                chosenItem[j] = new Furniture("A2", "IKEA", "Shelf", "L80 x W30 x H168 (cm）", "Easy to install, high quality materials", 87.9);
            }
            else if(id.equalsIgnoreCase("G5")){
                chosenItem[j] = new Furniture("G5", "Fuyoo", "Sofa", "W3200 x D2000 x H820 (cm)", "High Quality Microfabric", 3999.0);
            }
            else if(id.equalsIgnoreCase("H9")){
                chosenItem[j] = new Furniture("H9", "Sen", "Buffet Table", "W160 x D45 x H85 (cm)", "Compact, with two storage. Can be used as a sideboard", 2593.0);
            }
            else if(id.equalsIgnoreCase("P8")){
                chosenItem[j] = new Furniture("P8", "Jorlaina", "Dresser Table", "L100 x W40 x H120 (cm)", "Strong material", 2299.66);
            }
            else if(id.equalsIgnoreCase("X4")){
                chosenItem[j] = new Furniture("X4", "Elleni", "Nightstand", "L45 x D40 x H95 (cm)", "Item comes with 1-year structural warranty and does not include damages from wear and tear.", 1030.0);
            }
            else{
                System.out.println("The item ID you have entered do not exist!");
            }
        }
        ((FurnitureOrder)order).setItems(chosenItem);
        
        System.out.println("");
        System.out.println("TOTAL PRICE: RM"+order.calculateTotalPrice(quantity));
        System.out.println("Would you like to make payment now?");
        String pay = input.next();
        
        if(pay.equalsIgnoreCase("Yes")){
            System.out.println("");
            System.out.println("Please enter your bank name: ");
            String bankName = input.next();
            System.out.println("Please enter your bank account number: ");
            String bankAccount = input.next();
            Payment paymentMade = new Payment(bankName, bankAccount);
            order.setPayment(paymentMade);
            paymentMade.processPayment();
            DeliveryPerson delivery = new DeliveryPerson("Ahmad Daniel bin Syahir", "011-43871256", "MY1234567890BE");
            order.setDeliveryPerson(delivery);
            order.shipOut();
            order.showCompany();
        }
        else{
            System.out.println("");
            order.shipmentNotice();
        }
        
        
        //display order
        System.out.println("");
        System.out.println("");
        System.out.println("--- ORDER DETAIL ---");
        System.out.println("Order ID: "+order.getOrderID());
        System.out.println("Customer Name: "+customer.getName());
        System.out.println("Customer Email: "+customer.getEmail());
        System.out.println("Customer Address: "+customer.getAddress());
        System.out.println("Customer Phone Number: "+customer.getPhoneNumber());
        System.out.println("");
        
        System.out.println("Furniture ID\tBrand\t\tType\t\tPrice");
        System.out.println("-------------------------------------------------");
        for(int y=0;y<quantity;y++){
            //print items
            System.out.println(chosenItem[y].getId()+"\t\t"+chosenItem[y].getBrand()+"\t\t"+chosenItem[y].getType()+"\t\t"+chosenItem[y].getPrice());   //check balik
        }
        System.out.println("\t\t\t\tTotal Price: RM"+order.calculateTotalPrice(quantity));
        if(order.getPayment()==null){ 
            System.out.println("Payment: No");
        }
        else{
            System.out.println("Payment: Yes");
            System.out.println("Delivery Date: "+date);
            System.out.println("Delivery Person's Name: "+order.getDeliveryPerson().getName());
            System.out.println("Delivery Person's Phone Number: "+order.getDeliveryPerson().getPhoneNumber());
            System.out.println("Order Tracking Number: "+order.getDeliveryPerson().getTrackingNumber());
        }
        
        //repeat for the whole order
        System.out.println("");
        System.out.println("");
        System.out.println("Would you like to make another order?");
        String cont = input.next();
        if(cont.equalsIgnoreCase("No")){
            flag=1;
        }
        
        }
    }
}
