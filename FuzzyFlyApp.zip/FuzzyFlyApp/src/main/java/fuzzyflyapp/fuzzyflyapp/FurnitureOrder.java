/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuzzyflyapp.fuzzyflyapp;


/**
 *
 * @author aliya
 */
public class FurnitureOrder extends Order{
    private Furniture[] items;

    public FurnitureOrder(String orderID, Customer customer, Payment payment, DeliveryPerson deliveryPerson) {
        super(orderID, customer, payment, deliveryPerson);
    }

    public Furniture[] getItems() {
        return items;
    }

    public void setItems(Furniture[] items) {
        this.items = items;
    }

    @Override
    public String getOrderID() {
        return orderID;
    }

    @Override
    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    @Override
    public Customer getCustomer() {
        return customer;
    }

    @Override
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public double calculateTotalPrice(int quantity) { //in progress
        double total=0.0;
        for(int i=0;i<quantity;i++){
            total+=items[i].getPrice();
        }
        return total;
    }

    
}
