/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuzzyflyapp.fuzzyflyapp;

/**
 *
 * @author Swift 3
 */
class ClothParcel {
    private double weight;

    // Getters and Setters
    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}

class ClothJnt extends ClothCourier {
    public ClothJnt() {
        super("Jnt", 2.0);
    }
}

class ClothNinjaVan extends ClothCourier {
    public ClothNinjaVan() {
        super("NinjaVan", 3.0);
    }
}

class ClothPoslaju extends ClothCourier {
    public ClothPoslaju() {
        super("Poslaju", 1.5);
    }
}

