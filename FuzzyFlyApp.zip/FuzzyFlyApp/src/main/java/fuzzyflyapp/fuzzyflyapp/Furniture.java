package fuzzyflyapp.fuzzyflyapp;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aliya
 */
public class Furniture {
    private String id, brand, type, dimensions, description;
    private double price;

    public Furniture(String id, String brand, String type, String dimensions, String description, double price) {
        this.id = id;
        this.brand = brand;
        this.type = type;
        this.dimensions = dimensions;
        this.description = description;
        this.price = price;
    }
    
    public String getItemDetails(){
        return description+" - RM"+price;
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    
}
