/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuzzyflyapp.fuzzyflyapp;

/**
 *
 * @author Swift 3
 */
class ClothCourierFactory {
    public static ClothCourier[] getCouriers() {
        return new ClothCourier[] {
            new ClothJnt(),
            new ClothNinjaVan(),
            new ClothPoslaju()
        };
    }
}
